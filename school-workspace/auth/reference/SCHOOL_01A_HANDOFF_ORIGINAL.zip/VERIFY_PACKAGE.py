#!/usr/bin/env python3
from pathlib import Path, PurePosixPath
import json,hashlib
root=Path(__file__).resolve().parent
m=json.loads((root/'MANIFEST_SHA256.json').read_text())
for name,digest in m['files'].items():
 p=PurePosixPath(name)
 assert not p.is_absolute() and '..' not in p.parts,name
 f=root.joinpath(*p.parts)
 assert f.is_file() and hashlib.sha256(f.read_bytes()).hexdigest()==digest,name
actual={str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert actual==set(m['files'])|{'MANIFEST_SHA256.json'},'unexpected/missing files'
r=json.loads((root/'school-workspace/local/evidence/results.json').read_text())
assert r['pass']==34 and r['fail']==0 and len(r['tests'])==34
assert all(t['status']=='PASS' for t in r['tests'])
print('PASS package SHA-256 integrity and inventory; preserved result 34 PASS / 0 FAIL (local synthetic scope only)')
